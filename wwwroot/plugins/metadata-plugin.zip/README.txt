PIDAR Metadata Plugin for XNAT
================================

Plugin file: pidar-metadata-plugin-1.0-xpl.jar


INSTALLATION
------------
Copy the plugin JAR to your XNAT plugins directory:

    /home/xnat-docker-compose/xnat/plugins/

The plugins folder should then contain:
    pidar-metadata-plugin-1.0-xpl.jar   ← place it here

Restart XNAT after copying the file:

    docker compose restart xnat-web
    (or the equivalent restart command for your deployment)


WHAT IT DOES
------------
The plugin reads a JSON metadata file stored as a project resource in XNAT
and displays it as a "Metadata from PIDAR" section on the project detail page.

Expected resource path (per project):

    resources/metadata/{projectId}.json

Example:

    resources/metadata/pde5_liver.json

The JSON must be uploaded to each XNAT project under:
    Project → Manage → Resources → metadata → {projectId}.json


DISPLAYED FIELDS
----------------
The plugin renders the following fields from the JSON on the project page:

    - Dataset ID
    - Species
    - Organ/Tissue
    - Disease Model
    - Imaging Modality
    - Sample Size

A "Link to PIDAR" button is also shown, linking back to the dataset entry
in the PIDAR catalogue.


REQUIREMENTS
------------
- XNAT 1.8+
- The metadata JSON file must be present at the resource path above
- No additional configuration required


SOURCE
------
Plugin developed at the Institute of Biostructures and Bioimaging (IBB),
National Research Council of Italy (CNR), Torino.
Associated with the PIDAR platform: https://hpc4ai.unito.it
